# Bank Management System (Java)

A beginner-friendly console application demonstrating OOP, collections, validation, file persistence, and transaction history.

## Requirements
- Java 17 or newer

## Run the executable JAR
Open a terminal in the folder containing `BankManagementSystem.jar` and run:

```bash
java -jar BankManagementSystem.jar
```

The program creates a `bank-data` folder in the current working directory. Account and transaction data are saved there and loaded on the next run. Keep this folder if you want to preserve your demo data.

## Features
- Create account with generated account number
- Deposit and withdraw with amount validation and insufficient-balance check
- Check balance and search accounts
- List accounts
- View transaction history
- Persist data between runs

## Build from source
```bash
javac -d out src/BankManagementSystem.java
jar --create --file BankManagementSystem.jar --main-class BankManagementSystem -C out .
```

## Limitations
This is an educational demonstration, not banking software. It has no authentication, encryption, audit integrity controls, concurrency protection, or production-grade financial controls. Do not use it for real money or sensitive personal data. For a stronger portfolio project, add JDBC with PostgreSQL, unit tests, authentication/authorization, and a REST API, and document the work you personally complete.
