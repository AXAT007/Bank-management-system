import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Educational console-based Bank Management System. Not for real financial use. */
public class BankManagementSystem {
    private static final Path DATA_DIR = Paths.get("bank-data");
    private static final Path ACCOUNTS_FILE = DATA_DIR.resolve("accounts.csv");
    private static final Path TRANSACTIONS_FILE = DATA_DIR.resolve("transactions.csv");
    private static final Scanner IN = new Scanner(System.in);
    private static final Map<String, Account> ACCOUNTS = new LinkedHashMap<>();
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static int nextTransactionId = 1;

    static class Account {
        String number, name;
        double balance;
        Account(String number, String name, double balance) {
            this.number = number; this.name = name; this.balance = balance;
        }
    }
    static class Transaction {
        String id, accountNumber, type, timestamp, note;
        double amount, balanceAfter;
        Transaction(String id, String accountNumber, String type, double amount,
                    double balanceAfter, String note, String timestamp) {
            this.id=id; this.accountNumber=accountNumber; this.type=type; this.amount=amount;
            this.balanceAfter=balanceAfter; this.note=note; this.timestamp=timestamp;
        }
    }
    private static final List<Transaction> TRANSACTIONS = new ArrayList<>();

    public static void main(String[] args) {
        try {
            Files.createDirectories(DATA_DIR);
            loadData();
        } catch (IOException e) {
            System.out.println("Could not load bank data: " + e.getMessage());
            return;
        }
        System.out.println("========================================");
        System.out.println("       BANK MANAGEMENT SYSTEM");
        System.out.println("========================================");
        boolean running = true;
        while (running) {
            printMenu();
            int choice = readInt("Choose an option: ");
            try {
                switch (choice) {
                    case 1 -> createAccount();
                    case 2 -> deposit();
                    case 3 -> withdraw();
                    case 4 -> checkBalance();
                    case 5 -> showTransactions();
                    case 6 -> listAccounts();
                    case 7 -> searchAccount();
                    case 0 -> { saveData(); running = false; System.out.println("Data saved. Goodbye!"); }
                    default -> System.out.println("Invalid option. Try again.");
                }
            } catch (IOException e) {
                System.out.println("Could not save data: " + e.getMessage());
            }
            System.out.println();
        }
    }

    private static void printMenu() {
        System.out.println("\n--- MENU ---");
        System.out.println("1. Create account");
        System.out.println("2. Deposit money");
        System.out.println("3. Withdraw money");
        System.out.println("4. Check balance");
        System.out.println("5. View transaction history");
        System.out.println("6. List all accounts");
        System.out.println("7. Search account by number");
        System.out.println("0. Save and exit");
    }

    private static void createAccount() throws IOException {
        System.out.println("\n--- Create Account ---");
        String name = readNonEmpty("Customer full name: ");
        if (name.contains("|") || name.contains("\n")) { System.out.println("Please avoid | or newline characters in the name."); return; }
        String number;
        do { number = String.format("%06d", new Random().nextInt(1_000_000)); }
        while (ACCOUNTS.containsKey(number));
        Account account = new Account(number, name, 0.0);
        ACCOUNTS.put(number, account);
        record(account, "ACCOUNT_CREATED", 0.0, "Account created");
        saveData();
        System.out.println("Account created successfully!");
        System.out.println("Account number: " + number);
        System.out.println("Account holder: " + name);
        System.out.println("Opening balance: ₹0.00");
        System.out.println("Keep the account number safe; this demo has no password or login system.");
    }

    private static void deposit() throws IOException {
        System.out.println("\n--- Deposit ---");
        Account a = findAccount(readNonEmpty("Account number: "));
        if (a == null) { System.out.println("Account not found."); return; }
        double amount = readAmount("Amount to deposit (₹): ");
        a.balance = roundMoney(a.balance + amount);
        record(a, "DEPOSIT", amount, "Cash deposit"); saveData();
        System.out.printf(Locale.US, "Deposit successful. New balance: ₹%.2f%n", a.balance);
    }

    private static void withdraw() throws IOException {
        System.out.println("\n--- Withdraw ---");
        Account a = findAccount(readNonEmpty("Account number: "));
        if (a == null) { System.out.println("Account not found."); return; }
        double amount = readAmount("Amount to withdraw (₹): ");
        if (amount > a.balance) { System.out.println("Insufficient balance. Current balance: ₹" + money(a.balance)); return; }
        a.balance = roundMoney(a.balance - amount);
        record(a, "WITHDRAWAL", amount, "Cash withdrawal"); saveData();
        System.out.printf(Locale.US, "Withdrawal successful. New balance: ₹%.2f%n", a.balance);
    }

    private static void checkBalance() {
        System.out.println("\n--- Check Balance ---");
        Account a = findAccount(readNonEmpty("Account number: "));
        if (a == null) { System.out.println("Account not found."); return; }
        System.out.println("Account holder: " + a.name);
        System.out.printf(Locale.US, "Available balance: ₹%.2f%n", a.balance);
    }

    private static void showTransactions() {
        System.out.println("\n--- Transaction History ---");
        Account a = findAccount(readNonEmpty("Account number: "));
        if (a == null) { System.out.println("Account not found."); return; }
        boolean found = false;
        System.out.printf("%-5s %-20s %-15s %12s %14s  %s%n", "ID", "Date/time", "Type", "Amount", "Balance after", "Note");
        for (Transaction t : TRANSACTIONS) if (t.accountNumber.equals(a.number)) {
            found = true;
            System.out.printf(Locale.US, "%-5s %-20s %-15s %12.2f %14.2f  %s%n", t.id, t.timestamp, t.type, t.amount, t.balanceAfter, t.note);
        }
        if (!found) System.out.println("No transactions found.");
    }

    private static void listAccounts() {
        System.out.println("\n--- All Accounts ---");
        if (ACCOUNTS.isEmpty()) { System.out.println("No accounts created yet."); return; }
        System.out.printf("%-12s %-30s %14s%n", "Account No.", "Name", "Balance (₹)");
        for (Account a : ACCOUNTS.values()) System.out.printf(Locale.US, "%-12s %-30s %14.2f%n", a.number, a.name, a.balance);
    }

    private static void searchAccount() {
        Account a = findAccount(readNonEmpty("Account number: "));
        if (a == null) { System.out.println("Account not found."); return; }
        System.out.println("Account number: " + a.number);
        System.out.println("Account holder: " + a.name);
        System.out.printf(Locale.US, "Balance: ₹%.2f%n", a.balance);
    }

    private static Account findAccount(String number) { return ACCOUNTS.get(number.trim()); }
    private static void record(Account a, String type, double amount, String note) {
        TRANSACTIONS.add(new Transaction(String.valueOf(nextTransactionId++), a.number, type,
                roundMoney(amount), a.balance, note, LocalDateTime.now().format(TIME)));
    }
    private static double readAmount(String prompt) {
        while (true) {
            System.out.print(prompt); String s = IN.nextLine().trim();
            try { double v = Double.parseDouble(s); if (Double.isFinite(v) && v > 0) return roundMoney(v); }
            catch (NumberFormatException ignored) { }
            System.out.println("Enter a valid amount greater than zero.");
        }
    }
    private static int readInt(String prompt) {
        while (true) { System.out.print(prompt); try { return Integer.parseInt(IN.nextLine().trim()); }
            catch (NumberFormatException e) { System.out.println("Enter a whole number."); } }
    }
    private static String readNonEmpty(String prompt) {
        while (true) { System.out.print(prompt); String s = IN.nextLine().trim(); if (!s.isEmpty()) return s; System.out.println("This field cannot be empty."); }
    }
    private static double roundMoney(double value) { return Math.round(value * 100.0) / 100.0; }
    private static String money(double value) { return String.format(Locale.US, "%.2f", value); }

    private static void loadData() throws IOException {
        if (Files.exists(ACCOUNTS_FILE)) for (String line : Files.readAllLines(ACCOUNTS_FILE, StandardCharsets.UTF_8)) {
            String[] p = line.split("\\|", -1); if (p.length >= 3) try { ACCOUNTS.put(p[0], new Account(p[0], p[1], Double.parseDouble(p[2]))); } catch (NumberFormatException ignored) { }
        }
        if (Files.exists(TRANSACTIONS_FILE)) for (String line : Files.readAllLines(TRANSACTIONS_FILE, StandardCharsets.UTF_8)) {
            String[] p = line.split("\\|", -1); if (p.length >= 7) try {
                TRANSACTIONS.add(new Transaction(p[0],p[1],p[2],Double.parseDouble(p[3]),Double.parseDouble(p[4]),p[5],p[6]));
                nextTransactionId = Math.max(nextTransactionId, Integer.parseInt(p[0]) + 1);
            } catch (NumberFormatException ignored) { }
        }
    }
    private static void saveData() throws IOException {
        Files.createDirectories(DATA_DIR);
        List<String> accountLines = new ArrayList<>();
        for (Account a : ACCOUNTS.values()) accountLines.add(a.number + "|" + clean(a.name) + "|" + money(a.balance));
        Files.write(ACCOUNTS_FILE, accountLines, StandardCharsets.UTF_8);
        List<String> transactionLines = new ArrayList<>();
        for (Transaction t : TRANSACTIONS) transactionLines.add(t.id+"|"+t.accountNumber+"|"+t.type+"|"+money(t.amount)+"|"+money(t.balanceAfter)+"|"+clean(t.note)+"|"+t.timestamp);
        Files.write(TRANSACTIONS_FILE, transactionLines, StandardCharsets.UTF_8);
    }
    private static String clean(String s) { return s.replace('|', '/').replace('\n', ' ').replace('\r', ' '); }
}
